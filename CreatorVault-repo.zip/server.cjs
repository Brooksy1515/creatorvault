const http = require("http");
const fs = require("fs");
const path = require("path");

const port = process.env.PORT || 3000;
const file = path.join(__dirname, "sandbox.html");

const server = http.createServer((request, response) => {
  if (request.url !== "/" && request.url !== "/sandbox.html") {
    response.writeHead(302, { Location: "/" });
    response.end();
    return;
  }

  response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  fs.createReadStream(file).pipe(response);
});

server.listen(port, () => {
  console.log(`Creator Script Hub admin sandbox: http://localhost:${port}`);
});
