# CreatorVault

A beginner-friendly creator operating system for organizing affiliate products, samples, batch filming, raw clips, AI clips, scripts, posted videos, and performance notes.

## What is included

- Full Supabase schema with auth-linked tables and row level security policies
- Product Library with search and platform filters
- Script Builder with hook, pain point, voiceover, on-screen text, CTA, hashtags, and status fields
- Hook Bank with search and copy action
- Content Calendar for filming and posting plans
- Performance Tracker for views, likes, comments, clicks, sales, and notes
- Sample app data and Supabase seed data

## Setup

1. Install dependencies:

```bash
npm install
```

2. Add your Supabase keys:

```bash
cp .env.local.example .env.local
```

3. Run `supabase/schema.sql` in your Supabase SQL editor.

4. Optional: update the user ID in `supabase/seed.sql`, then run it in Supabase to add starter data.

5. Start the app:

```bash
npm run dev
```

Open `http://localhost:3000`.
